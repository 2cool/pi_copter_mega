package copter.rc2;

/**
 * Created by igor on 8/19/2016.
 */
public class Rectangle {
    int width,height;
}
